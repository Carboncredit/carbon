package Dao;

import java.sql.*;
import javax.sql.DataSource;
import javax.naming.*;

public class SchoolDao {
	DataSource dataSource;
    public SchoolDao() {
	  try {
		  System.out.println("90");
	     Context context =new InitialContext();
	     dataSource = (DataSource)context.lookup("java:comp/env/jdbc/schoolDS");
	  }catch(NamingException ne){
	      System.out.println("Exception:"+ne);
	  }
	}
	public Connection getConn() throws Exception{
		return dataSource.getConnection();
	}
}
