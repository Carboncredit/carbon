package Dao;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.ArrayList;

import javax.servlet.http.HttpServlet;

import model.Carbon;
import model.User;


public class UserDao{
	
	String url = "jdbc:mysql://127.0.0.1:3306/db?serverTimezone=GMT%2B8&useSSL=false";
	String uName ="root";
	String uPwd="w23456765432";

	//查找所有用户
	public ArrayList<User> findAllUser() {
		ArrayList<User> userList = new ArrayList<User>();
		String sql = "SELECT * FROM user_info";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection conn = DriverManager.getConnection(url,uName,uPwd);
        	PreparedStatement pstmt = conn.prepareStatement(sql);
        	ResultSet rst = pstmt.executeQuery(sql);
			while (rst.next()) {
				User user=new User();
				user.setUserid(rst.getString("userid").trim());
				user.setPassword(rst.getString("password").trim());
				user.setRealname(rst.getString("realname").trim());
				user.setSex(rst.getString("sex").trim());
				user.setCarbonpoints(rst.getInt("carbonpoints"));
				user.setLevel(rst.getInt("level"));
				user.setViptype(rst.getString("viptype").trim());
				userList.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return userList; 
	}
	
	//--------------判断登录正确性
	public boolean UserLogin(String uid,String password) {
		String sql = "SELECT password FROM user_info WHERE userid= ? ";
		String pass=null;
		try { 
				Class.forName("com.mysql.cj.jdbc.Driver");
	        	Connection conn = DriverManager.getConnection(url,uName,uPwd);
	        	PreparedStatement pstmt = conn.prepareStatement(sql);
	        	pstmt.setString(1, uid);
			try (ResultSet rst = pstmt.executeQuery()) {
				if (rst.next()) {
					pass=rst.getString("password").trim();
					if(password.equals(pass)) {
						return true;
					}
				}
			} 
		} catch (SQLException se) {
			se.printStackTrace();
			return false;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	//------------通过id找用户
	public User findUserByID(String uid) {
		String sql = "SELECT * FROM user_info WHERE userid= ? ";
		User user = new User();
		try { 
			Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection conn = DriverManager.getConnection(url,uName,uPwd);
        	PreparedStatement pstmt = conn.prepareStatement(sql);
        	pstmt.setString(1, uid);
        	try (ResultSet rst = pstmt.executeQuery()) {
				if (rst.next()) {
					user.setUserid(rst.getString("userid").trim());
					user.setPassword(rst.getString("password").trim());
					user.setRealname(rst.getString("realname").trim());
					user.setSex(rst.getString("sex").trim());
					
					user.setCarbonpoints(rst.getInt("carbonpoints"));
					user.setLevel(rst.getInt("level"));
					user.setViptype(rst.getString("viptype").trim());
	
				}
			} 
		} catch (SQLException se) {
			se.printStackTrace();
			return null;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	//查找所有用户
		public ArrayList<Carbon> findCarbonByid(String uid) {
			ArrayList<Carbon> carbonList = new ArrayList<Carbon>();
			String sql = "SELECT * FROM carbonpoints WHERE userid= ? ";
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
	        	Connection conn = DriverManager.getConnection(url,uName,uPwd);
	        	PreparedStatement pstmt = conn.prepareStatement(sql);
	        	pstmt.setString(1, uid);
	        	ResultSet rst = pstmt.executeQuery(sql);
				while (rst.next()) {
					Carbon carbon=new Carbon();
					carbon.setOrderid(rst.getString("orderid").trim());
					carbon.setUserid(rst.getString("userid").trim());
					
					carbon.setCarbonpoints(rst.getInt("carbonpoints"));
					carbon.setChange(rst.getInt("change"));
					
					carbon.setRemark(rst.getString("remark").trim());
					carbonList.add(carbon);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			return carbonList; 
		}
	
	
	
	

}
