package model;

public class Signin {
	
	private String userid;		
	private String signin;
	public Signin() {
		super();
	}
	public Signin(String userid, String signin) {
		super();
		this.userid = userid;
		this.signin = signin;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getSignin() {
		return signin;
	}
	public void setSignin(String signin) {
		this.signin = signin;
	}	
	
	

}
