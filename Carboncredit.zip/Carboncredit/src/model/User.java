package model;

public class User {
	private String userid;      	//用户名
	private String password;		//密码
	private String realname;		//用户姓名
	private String sex;				//性别
	private int carbonpoints;		//碳积分
	private int level;				//用户等级
	private String viptype;			//会员类型
	
	public User() {
		super();
	}
	public User(String userid, String password, String realname, String sex, int carbonpoints, int level,
			String viptype) {
		super();
		this.userid = userid;
		this.password = password;
		this.realname = realname;
		this.sex = sex;
		this.carbonpoints = carbonpoints;
		this.level = level;
		this.viptype = viptype;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getCarbonpoints() {
		return carbonpoints;
	}
	public void setCarbonpoints(int carbonpoints) {
		this.carbonpoints = carbonpoints;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getViptype() {
		return viptype;
	}
	public void setViptype(String viptype) {
		this.viptype = viptype;
	}

	

}
