package model;

import java.util.Date;
import java.util.Calendar;

public class Trip {
	private int tripid;      	
	private String userid;		
	private String servicetype;		
	private Date starttime;			
	private int startplace;		
	private Date endtime;				
	private int endplace;		
	private String paymethod;
	
	public Trip() {
		super();
	}
	public Trip(int tripid, String userid, String servicetype, Date starttime, int startplace, Date endtime,
			int endplace, String paymethod) {
		super();
		this.tripid = tripid;
		this.userid = userid;
		this.servicetype = servicetype;
		this.starttime = starttime;
		this.startplace = startplace;
		this.endtime = endtime;
		this.endplace = endplace;
		this.paymethod = paymethod;
	}
	public int getTripid() {
		return tripid;
	}
	public void setTripid(int tripid) {
		this.tripid = tripid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getServicetype() {
		return servicetype;
	}
	public void setServicetype(String servicetype) {
		this.servicetype = servicetype;
	}
	public Date getStarttime() {
		return starttime;
	}
	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}
	public int getStartplace() {
		return startplace;
	}
	public void setStartplace(int startplace) {
		this.startplace = startplace;
	}
	public Date getEndtime() {
		return endtime;
	}
	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}
	public int getEndplace() {
		return endplace;
	}
	public void setEndplace(int endplace) {
		this.endplace = endplace;
	}
	public String getPaymethod() {
		return paymethod;
	}
	public void setPaymethod(String paymethod) {
		this.paymethod = paymethod;
	}
	
	
}
