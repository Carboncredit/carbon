package model;

import java.util.Date;

public class Carbon {
	
	private String orderid;		
	private String userid;	
	private int carbonpoints; 
	private int change; 	
	private String remark;
	
	public Carbon() {
		super();
	}
	public Carbon(String orderid, String userid, int carbonpoints, int change, String remark) {
		super();
		this.orderid = orderid;
		this.userid = userid;
		this.carbonpoints = carbonpoints;
		this.change = change;
		this.remark = remark;
	}
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getCarbonpoints() {
		return carbonpoints;
	}
	public void setCarbonpoints(int carbonpoints) {
		this.carbonpoints = carbonpoints;
	}
	public int getChange() {
		return change;
	}
	public void setChange(int change) {
		this.change = change;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	

}
